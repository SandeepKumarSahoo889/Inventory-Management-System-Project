/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.project.inventorymanagement;

/**
 *
 * @author sandeepsahoo
 */
public class InventoryManagement {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
